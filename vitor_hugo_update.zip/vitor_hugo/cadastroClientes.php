<?php
		session_start();
	
		$cpf = $_POST["cpf"];
		$cep = $_POST["cep"]; 
		/*$senha_segura = password_hash($senha, PASSWORD_DEFAULT);*/
		
		include("conexao.php");
		$cadastro = mysqli_query($conection, "INSERT INTO clientes(cpf, cep) VALUES ('$cpf', '$cep')");
		header('Location: dashboard.php?isSucess=true');
?>

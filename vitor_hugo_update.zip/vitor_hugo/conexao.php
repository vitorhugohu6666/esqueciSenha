<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$database = "vitor_hugo";
	
	$conection = mysqli_connect($servername, $username, $password, $database);
?>
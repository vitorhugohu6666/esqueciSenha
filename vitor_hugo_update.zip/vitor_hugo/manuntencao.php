<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manuntenção</title>
	<!-- CSS Boostrapp -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	<style>
		.img-fluid {
			height: 350px;
			width: 500px;
			border-radius: 20px;
			margin-top: 50px;
		}
	</style>
</head>

<!--<script type="text/javascript"> 
		window.location = "login.php"
 </script> -->

<body class="p-3 mb-2 bg-primary text-white">
<center>

<img src="imagens/man.jpg" class="img-fluid" alt="Logo Marca" >

</center>

</body>
</html>
<?php
		session_start();

		$usuario = $_POST["nome"];
		$senha = $_POST["senha"]; 
		$email = $_POST["email"];
		$senha_segura = password_hash($senha, PASSWORD_DEFAULT);
		
		include("conexao.php");
		$cadastro = mysqli_query($conection, "INSERT INTO usuarios(nome, senha, email) VALUES ('$usuario', '$senha_segura', '$email')");
		header('Location: dashboard.php?isSucess=true');
?>


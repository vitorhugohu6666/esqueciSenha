<?php
include("conexao.php");

$emailDigitado = $_POST['emailRecupera'];
$senhaDigitada = $_POST['senhaRecupera'];

$recupera = mysqli_query($conection, "SELECT email FROM usuarios WHERE email = '$emailDigitado'");
$resultadoRecupera = mysqli_fetch_assoc($recupera);

$emailRecupera = $resultadoRecupera['email'];

if($emailDigitado == $emailRecupera) {
    $senhaHash = password_hash($senhaDigitada, PASSWORD_DEFAULT);
    $atualizarSenha = mysqli_query($conection, "UPDATE usuarios SET senha = '$senhaHash' WHERE email = '$emailDigitado'");
    header('Location: esqueceuSenha.php?valor=1');
} else {
    header('Location: esqueceuSenha.php?erro=1');
}

?>
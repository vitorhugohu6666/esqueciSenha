<?php
include("conexao.php");

$emailDigitado = $_POST['emailSenha'];

$emailBanco = mysqli_query($conection);
?>